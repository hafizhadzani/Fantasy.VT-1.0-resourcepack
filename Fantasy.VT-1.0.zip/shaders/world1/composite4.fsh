#version 400 compatibility
#define DIMENSION_END

#include "/program/composite4.fsh"